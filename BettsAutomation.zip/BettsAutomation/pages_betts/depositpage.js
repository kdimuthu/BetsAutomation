import { test, expect } from '@playwright/test';

export class DepositPage{

    constructor(page) {

        this.page = page

        /* ======== deposit ==========================================*/
        this.tf_Amount = page.locator("//input[@id='depositAmount']") 
        this.btn_Visa = page.locator("//button[@id='btnVisa']/span[1]")     
        this.btn_Master = page.locator("")  
        this.btn_iPay = page.locator("")  

        /* ======== card details ==========================================*/
        this.tf_CardNumber = page.locator("//input[@id='cardNumber']") 
        this.dd_ExpiryMonth = page.locator("//select[@id='expiryMonth']") 
        this.dd_ExpiryYear = page.locator("//select[@id='expiryYear']")
        this.tf_CardholderName = page.locator("//input[@id='cardHolderName']")  
        this.tf_SecurityCode = page.locator("//input[@id='csc']") 
        this.btn_PayNow = page.locator("//a[text()='Cancel']/following::button[text()='Pay now'][1]") 
        this.btn_SubmitInPaymentProcess = page.locator("//input[@type='submit']") 

        /* ======== Success pop up ==========================================*/
        this.btn_OkFromSuccessPopUp = page.locator("//span[@class='caption' and text()='Next 15']/following::span[contains(text(),'OK')][1]")
        
    }  

    //Enter an amount to be deposited
    async rc_EnterAnAmountAndClickVisaMasterOrIpay(paymentMethod) {   

        await this.page.waitForTimeout(5000)
        //Enter an amount
        await this.tf_Amount.fill("5000")

        if(paymentMethod==="Visa"){
            //Click on Visa button
            await this.btn_Visa.click()
        }

        else if(paymentMethod==="Master"){
            //Click on Master button
            await this.btn_Master.click()
        }

        else if(paymentMethod==="iPay"){
            //Click on ipay button
            await this.btn_iPay.click()
        }        
        
    }

     //Enter card details and click pay now
    async rc_EnterCardDetailsAndClickPayNow() {        
        
        await this.page.waitForTimeout(5000)
        //Enter card number
        await this.tf_CardNumber.fill("4012000033330026")
        //Select expiry month
        await this.dd_ExpiryMonth.selectOption("01")
        //Select expiry year
        await this.dd_ExpiryYear.selectOption("39")
        //Enter cardholder name
        await this.tf_CardholderName.fill("Dimuthu")
        //Enter security code
        await this.tf_SecurityCode.fill("100")
        //click pay now button
        await this.btn_PayNow.click()    
        await this.page.waitForTimeout(5000)            
    }

    //Click ok from success pop up
    async rc_ClickOkFromSuccessPopup() {        
      
        //Click Ok
        await this.btn_OkFromSuccessPopUp.click()     
        
    }
    
}