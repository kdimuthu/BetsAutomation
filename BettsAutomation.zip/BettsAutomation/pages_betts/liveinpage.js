import { test, expect } from '@playwright/test';

export class LiveInPage{

    constructor(page) {

        this.page = page
        
        /* ===========================  Cricket Section ===================================================*/
        
        this.lnk_FirstCricketMatch = page.locator("//span[text()='Live in Play']/following::div[@class='sport-item'][1]/div")
        this.lnk_SecondCricketMatch = page.locator("//span[text()='Live in Play']/following::div[@class='sport-item'][1]/div")
        this.lnk_ThirdCricketMatch = page.locator("//span[text()='Live in Play']/following::div[@class='sport-item'][1]/div")

        /* ===========================  Cricket Section | Single Sport View ================================*/

        this.btn_FirstOddOnFirstMatch = page.locator("//span[contains(text(),'All (')]/following::div[@class='mat-caption'][1]/parent::span")
        this.btn_SecondOddOnFirstMatch = page.locator("//span[contains(text(),'All (')]/following::div[@class='mat-caption'][2]/parent::span")
        this.lnk_SecondMarket = page.locator("//span[contains(text(),'All (')]/following::mat-panel-title[3]")
        
        this.btn_FirstOddInSecondMarket = page.locator("//span[contains(text(),'All (')]/following::mat-panel-title[3]/following::span[@class='mat-button-wrapper'][1]")
        this.btn_SecondOddInSecondMarket = page.locator("//span[contains(text(),'All (')]/following::mat-panel-title[3]/following::span[@class='mat-button-wrapper'][1]")
    
    }

    //Click on the first game
    async rc_ClickOnAGame(matchNumber) {            
        await this.page.waitForTimeout(5000)

        if(matchNumber=="First"){
        //Click on first game
        await this.lnk_FirstCricketMatch.click()
        }
        else if(matchNumber=="Second"){
        //Click on second game
        await this.lnk_SecondCricketMatch.click()
        }
        else if(matchNumber=="Third"){
        //Click on third game
        await this.lnk_ThirdCricketMatch.click()    
        }

    }

    //Click on the odd buttons in winner market
    async rc_ClickOnOddButtonInrMarketFromSingleSportView(FirstOrSecond) {       

        await this.page.waitForTimeout(5000)
        if(FirstOrSecond==="First"){
            //Click on first odd button in winner market
            await this.btn_FirstOddOnFirstMatch.click()
        }
        else if(FirstOrSecond==="Second"){
            //Click on second button in winner market
            await this.btn_SecondOddOnFirstMatch.click()
        }         
        else if(FirstOrSecond==="Third"){
            //Click on first odd button in second market
            await this.btn_FirstOddInSecondMarket.click()
        }   

    }

    //Click on the 2nd market game
    async rc_ClickOnSecondMarketFromSingleSportView() { 

        await this.page.waitForTimeout(5000)
        //Click on second market
        await this.lnk_SecondMarket.click()
    }

    
}