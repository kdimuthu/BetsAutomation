import { test, expect } from '@playwright/test';

export class CreateAccountPage{

    constructor(page) {

        this.page = page
        
        /* ========   ====================================*/       

    }

    
}