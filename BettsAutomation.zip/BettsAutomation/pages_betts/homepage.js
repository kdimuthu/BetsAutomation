import { test, expect } from '@playwright/test';

export class HomePage {

    constructor(page) {

        this.page = page

        /* ========Top bar===================================================*/

        this.icn_BetssLogo = page.locator("//span[@class='caption' and text()='Live in Play']/preceding::img[2]")
        this.icn_Enlish = page.locator("//span[@class='caption' and text()='Live in Play']/preceding::button[8]")
        this.icn_Sinhala = page.locator("//span[@class='caption' and text()='Live in Play']/preceding::button[7]")
        this.icn_Tamil = page.locator("//span[@class='caption' and text()='Live in Play']/preceding::button[6]")
        this.icn_Profile = page.locator("//span[text()='Cricket']/preceding::input[@type='checkbox'][1]")
        this.icn_LiveInPlay = page.locator("//span[@class='caption' and text()='Live in Play']/preceding::img[1]")
        this.lnk_LiveInPlay = page.locator("//span[@class='caption' and text()='Live in Play']")
        this.lnk_Next15 = page.locator("//span[@class='caption' and text()='Next 15']")
        this.lnk_Cricket = page.locator("//span[@class='caption' and text()='Cricket']")
        this.lnk_Racing = page.locator("//span[@class='caption' and text()='Racing']")
        this.lnk_Soccer = page.locator("//span[@class='caption' and text()='Soccer']")
        this.lnk_WatchAndBet = page.getByText('Watch & Bet')
        this.lnk_AllSport = page.locator("//span[@class='caption' and text()='All Sport']")         
               
        /* ========Left Menu ================================================*/

        this.lnk_PopularSports = page.locator("//mat-panel-title[contains(text(),'Popular Sports')]")
        this.lnk_PopularRacing = page.locator("//mat-panel-title[contains(text(),'Popular Racing')]")
        this.lnk_FirstMatchInPopularSports=page.locator("//mat-panel-title[contains(text(),'Popular Sports')]/following::div[@class='popular-date'][1]")
        this.lnk_FirstRaceInPopularRacing=page.locator("//mat-panel-title[contains(text(),'Popular Racing')]/following::h4[1]")
        this.btn_FirstOddInPopularRacing=page.locator("//mat-panel-title[contains(text(),'Popular Racing')]/following::button[1]")        
        this.lnk_AllRacing = page.locator("//mat-panel-title[contains(text(),'All Racing')]")
        this.lnk_HorseRacingInAllRacing=page.getByRole('link', { name: 'Horse Racing' })
        this.lnk_GreyhoundRacingInAllRacing=page.getByRole('link', { name: 'Greyhound Racing' })
        this.lnk_HarnessRacingInAllRacing=page.getByRole('link', { name: 'Harness Racing' })
        this.lnk_KiranVirrualRacingInAllRacing=page.getByRole('link', { name: 'Kiron Virtual Races' })
        this.lnk_NuwaraEliyaRacingInAllRacing=page.getByRole('link', { name: 'Nuwara Eliya Racing' }) 
        this.lnk_AllSportsInLeftmenu = page.locator("//mat-panel-title[contains(text(),'All Sports')]")
        this.lnk_BasketballInAllSports=page.locator("//mat-panel-title[contains(text(),'All Sports')]/following::span[text()='Basketball']")
        this.lnk_BoxingInAllSports=page.locator("//mat-panel-title[contains(text(),'All Sports')]/following::span[text()='Boxing']")
        this.lnk_CricketInAllSports=page.locator("//mat-panel-title[contains(text(),'All Sports')]/following::span[text()='Cricket']")
        this.lnk_Formula1InAllSports=page.locator("//mat-panel-title[contains(text(),'All Sports')]/following::span[text()='Formula 1']")
        this.lnk_RugbyInAllSports=page.locator("//mat-panel-title[contains(text(),'All Sports')]/following::span[text()='Rugby']")
        this.lnk_SoccerInAllSports=page.locator("//mat-panel-title[contains(text(),'All Sports')]/following::span[text()='Soccer']")
        this.lnk_TennisInAllSports=page.locator("//mat-panel-title[contains(text(),'All Sports')]/following::span[text()='Tennis']")

        /* ========Right Menu -Bet Slip ====================================*/
        
        this.lbl_BetSlip = page.locator("//mat-panel-title[contains(text(),'Bet Slip')]/text()")
        this.val_BetSlipZero = page.locator("//mat-panel-title[contains(text(),'Bet Slip')]/span")
        this.lbl_LKR0 = page.locator("//p[contains(@class,'amount')]")
        this.btn_PlaceBet = page.locator("//span[text()='Place Bet']")
        this.btn_Clear = page.locator("//span[text()='Clear']")
        this.lbl_BetsWillBeAdded = page.locator("//div[contains(text(),'Bets will')]")
        this.lnk_RecentBets = page.locator("//mat-panel-title[contains(text(),'Recent')]")
        this.lbl_PleaseLoginToSystemInRecentBets = page.locator("//mat-panel-title[contains(text(),'Recent')]/following::div[contains(text(),'Please')][1]/text()")
        this.btn_JoinInRecentBets = page.locator("//mat-panel-title[contains(text(),'Recent')]/following::button[1]")        
        this.lnk_Results = page.locator("//mat-panel-title[contains(text(),'Results')]")
        this.lbl_PleaseLoginToSystemInResults = page.locator("//mat-panel-title[contains(text(),'Result')]/following::div[contains(text(),'Please')][1]/text()")
        this.btn_JoinInResults = page.locator("//mat-panel-title[contains(text(),'Result')]/following::button[1]")
        this.lnk_RacingPapers = page.locator("//mat-panel-title[contains(text(),'Racing Papers')]")
        this.lbl_PleaseLoginToSystemInRacingPapers = page.locator("//mat-panel-title[contains(text(),'Racing Papers')]/following::div[contains(text(),'Please')][1]/text()")
        this.btn_JoinInRacinRacingPapers = page.locator("//mat-panel-title[contains(text(),'Racing Papers')]/following::button[1]")
        this.lnk_NewsFeed = page.locator("//span[contains(text(),'News')]")
        this.img_RacingPost = page.locator("//span[contains(text(),'News')]/following::div[@class='child bg-one']")
        this.lnk_RacingPostWhenHouringMouse = page.locator("//span[contains(text(),'News')]/following::div[@class='child bg-one']/a")
        this.img_SportingLife = page.locator("//span[contains(text(),'News')]/following::div[@class='child bg-one']")
        this.lnk_SportingLifeWhenHouringMouse = page.locator("//span[contains(text(),'News')]/following::div[@class='child bg-one']/a")
        this.tf_Win = page.locator("//span[text()='Clear']/following::input[1]")
        this.tf_Place = page.locator("//span[text()='Clear']/following::input[2]")
        this.tf_WinSingleInMultipleOptions = page.locator("//*[contains(text(),'Multiple')]/following::input[1]")
        this.tf_PlaceSingleInMultipleOptions = page.locator("//*[contains(text(),'Multiple')]/following::input[2]")
        this.tf_WinDoubleInMultipleOptions = page.locator("//*[contains(text(),'Double')]/following::input[1]")
        this.tf_PlaceDoubleInMultipleOptions = page.locator("//*[contains(text(),'Double')]/following::input[2]")      
        this.chk_EachWay = page.locator("//span[text()='Clear']/following::input[@type='checkbox']")
        this.tf_Stake = page.locator("")        
        this.msg_MinimumSlipAmountShouldBe = page.locator("//span[text()='Clear']/following::p[6]")
        this.msg_MinimumStakeValueShouldBe = page.locator("//span[text()='Clear']//following::p[contains(text(),'Stake')]")
        this.msg_BetssSuccessfullyPlaced = page.locator("//p[contains(text(),'Successfully')]")
        this.btn_OKBetssSuccessPopUp = page.locator("//span[text()='OK']")
        this.msg_InsufficientBalance = page.locator("//span[text()='Clear']//following::p[contains(text(),'Insufficient ')][1]")
        this.msg_WinStakeShouldBeGreaterThanOrEqualToPlaceStake = page.locator("//span[text()='Clear']/following::p[contains(text(),'greater')]")
        this.msg_YouAreNotAllowedToPlaceBetsWithoutWinStake = page.locator("//span[text()='Clear']/following::p[contains(text(),'allowed')]")
        this.msg_OddValueHasBeenUpdated = page.locator("//mat-label[contains(text(),'Odd')]")       

        /* ========Login icon section=================================*/

        this.lnk_LoginButton = page.locator("//span[contains(text(),'LOGIN')]")
        this.lnk_JoinButton = page.locator("//span[contains(text(),'JOIN')]")  
        
        /* ========After Login Section ====================================*/

        this.icn_ProfileAfterLogin = page.locator("//span[text()='Cricket']/preceding::input[@type='checkbox'][2]")
        this.icn_BellForNotification = page.locator("//mat-icon[contains(@class,'notification-icon')]")
        this.lnk_WatchAndBett = page.locator("//mat-icon[contains(@class,'notification-icon')]")
        this.val_CreditBalance=page.locator("//div[@class='notification']/descendant::span[1]")             
       
        /* ========Right Menu ====================================*/

        this.lnk_MyBets = page.locator("//span[contains(text(),'My Bets')]")
        this.lnk_MyTransctions = page.locator("")
        this.lnk_Withdraw = page.locator("")
        this.lnk_Deposit = page.locator("//span[contains(text(),'Deposit')]")
        this.lnk_MyBankAccount = page.locator("")
        this.lnk_Bonus = page.locator("")
        this.rdo_Fraction = page.locator("//span[contains(text(),'Fraction')]/preceding::input[@type='checkbox'][1]")
        this.btn_OKFromOddFormatChangingSuccessPopup = page.locator("//p[contains(text(),'format')]/following::span[text()='OK']")
        this.lnk_RecentBets = page.locator("//mat-panel-title[contains(text(),'Recent')]")
        this.lnk_FirstBetInRecentBets = page.locator("//mat-panel-title[contains(text(),'Recent')]/following::mat-panel-title[1]")
        this.lnk_Results = page.locator("//mat-panel-title[contains(text(),'Results')]") 
        this.lnk_RacingPost = page.locator("//span[contains(text(),'News')]/following::a[contains(text(),'Racing')]")  
        this.img_RacingPost = page.locator("//span[contains(text(),'News')]/following::a[contains(text(),'Racing')]/parent::div")  
        this.lnk_SportingLife = page.locator("//span[contains(text(),'News')]/following::a[contains(text(),'Sporting')]")
        this.img_SportingLife = page.locator("//span[contains(text(),'News')]/following::a[contains(text(),'Sporting')]/parent::div")    

        /* ========Results ====================================*/

        this.lnk_HorseRacing = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Horse')]")
        this.lnk_Greyhound = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Grey')]")
        this.lnk_Cricket = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Cricket')]")
        this.lnk_Rugby = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Rugby')]")
        this.lnk_Soccer = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Soccer')]")
        this.lnk_HarnessRacing = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Harness')]")
        this.lnk_KironVirtualRacing = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Kiron')]")
        this.lnk_BaseketballInSports = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Basketball')]")
        this.lnk_BoxingInSports = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Boxing')]")
        this.lnk_Formula1InSports = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Formula')]")
        this.lnk_TennisInSports = page.locator("//span[contains(text(),'Result')]/following::span[contains(text(),'Tennis')]")
        this.icn_BackButton = page.locator("//div[@class='back-icon']")
        this.lnk_FirstResultInHorseRacing = page.locator("//div[contains(text(),'Horse')]/following::span[contains(@class,'main')][1]")
        this.lnk_FirstResultInGrayhoundRacing = page.locator("//div[contains(text(),'Gray')]/following::span[contains(@class,'main')][1]")
        this.lnk_FirstResultInCricket = page.locator("//div[contains(text(),'Cricket')]/following::table")
        this.lnk_FirstResultInRugby = page.locator("//div[contains(text(),'Rugby')]/following::table")
        this.lnk_FirstResultInSoccer = page.locator("//div[contains(text(),'Soccer')]/following::table")
        this.lnk_FirstResultInHarnessRacing = page.locator("//div[contains(text(),'Today')]/following::span[contains(@class,'main')][1]")
        this.lnk_FirstResultInKironVirtualRacing = page.locator("//div[contains(text(),'Kiron')]/following::span[contains(@class,'main')][1]")
        this.lnk_FirstResultInBasketball = page.locator("//div[contains(text(),'Basketball')]/following::table")
        this.lnk_FirstResultInBoxing = page.locator("//div[contains(text(),'Boxing')]/following::table")
        this.lnk_FirstResultInFormula = page.locator("//div[contains(text(),'Boxing')]/following::table")         
        

        /* ========My Bets Section====================================*/

        this.lbl_SlilpId = page.locator("//span[contains(text(),'My Bets')]/following::span[text()='Slip ID'][1]")
        this.val_SlilpId = page.locator("//span[contains(text(),'My Bets')]/following::p[contains(text(),'BETS')][1]")
        this.lbl_TotalStake = page.locator("//span[contains(text(),'My Bets')]/following::span[text()='Total Stake'][1]")
        this.val_TotalStake = page.locator("//span[contains(text(),'My Bets')]/following::p[contains(text(),'LKR')][1]")
        this.lbl_TotalReturn = page.locator("")
        this.val_TotalReturn = page.locator("//span[contains(text(),'My Bets')]/following::p[contains(text(),'LKR')][2]")
        this.lbl_DateAndTime = page.locator("")
        this.val_DateAndTime = page.locator("")
        this.btn_FirstExpand = page.locator("//span[contains(text(),'My Bets')]/following::span[contains(text(),'Date')][1]/following::span[1]")
        this.btn_SecondExpand = page.locator("")
        this.lbl_Selection = page.locator("//span[contains(text(),'My Bets')]/following::span[contains(text(),'Selection')][1]")
        this.val_Selection = page.locator("//span[contains(text(),'My Bets')]/following::span[contains(text(),'Selection')][1]/following::p[1]")
        this.lbl_Market = page.locator("//span[contains(text(),'My Bets')]/following::span[contains(text(),'Market')][1]")
        this.val_Market = page.locator("//span[contains(text(),'My Bets')]/following::span[contains(text(),'Market')][1]/following::p[1]")
        this.val_MarketForSecondSelection = page.locator("//span[contains(text(),'My Bets')]/following::span[contains(text(),'Market')][2]/following::p[1]")        
        this.lbl_Stake = page.locator("//span[contains(text(),'My Bets')]/following::span[contains(text(),'Stake')][2]")
        this.val_Stake = page.locator("//span[contains(text(),'My Bets')]/following::p[contains(text(),'LKR')][3]")
        this.val_StakeForSecondSelection = page.locator("//span[contains(text(),'My Bets')]/following::span[contains(text(),'Market')][2]/following::p[contains(text(),'LKR')][1]")
        this.lbl_Payout = page.locator("//span[contains(text(),'My Bets')]/following::span[contains(text(),'Payout')][1]")
        this.val_Payout = page.locator("//span[contains(text(),'My Bets')]/following::p[contains(text(),'LKR')][4]")
        this.val_PayoutForWinDouble = page.locator("//span[contains(text(),'My Bets')]/following::p[contains(text(),'LKR')][6]")        
        this.val_PayoutForSecondSelection = page.locator("//span[contains(text(),'My Bets')]/following::span[contains(text(),'Market')][2]/following::p[contains(text(),'LKR')][2]")
        
        /* ========Before logging ====================================*/

        this.msg_YouHaveToLogInToSystemBeforePlacingABet = page.locator("//p[contains(text(),'before')]")
        this.msg_YouHaveToLogInToTheSystemToAccessKironVirtual = page.locator("//p[contains(text(),'access Kiron')]")

        /* ========Footer ============================================*/

        this.btn_Help = page.locator("//mat-panel-title[contains(text(),'Help')]")
        this.lnk_FAQ = page.locator("//a[text()='FAQ']")
        this.lnk_HelpUnderHelp = page.locator("//a[text()='Help']")
        this.btn_TermsAndPrivacy = page.locator("//mat-panel-title[contains(text(),'Terms')]")       
        this.lnk_TermsAndCondition = page.locator("//u[contains(text(),'Terms')]")
        this.lnk_PrivacyPolicy = page.locator("//u[contains(text(),'Privacy')]")
        this.lnk_PrivacyPolicy = page.locator("//u[contains(text(),'Rules')]")
        this.btn_FindUs = page.locator("//mat-panel-title[contains(text(),'Find')]")
        this.lnk_AbountUs = page.locator("//a[contains(text(),'About')]")
        this.lnk_ContactUs = page.locator("//a[contains(text(),'Contact')]")
        this.lbl_MessageInFotter = page.locator("//mat-panel-title[contains(text(),'Help')]/following::p[1]")
        this.lbl_AllRightsReserved = page.locator("//mat-panel-title[contains(text(),'Help')]/following::p[2]")
        this.icn_Facebook = page.locator("//mat-panel-title[contains(text(),'Help')]/following::img[1]")
        this.icn_Instagram = page.locator("//mat-panel-title[contains(text(),'Help')]/following::img[2]")

    }

    //Open the application
    async rc_OpenApplication() {

        //Open the applicatoin
        await this.page.goto("")
    }

    //Click login profile icon
    async rc_ClickLoginIcon() {

       //Click profile icon
       await this.icn_Profile.click()
    }

    //Click login buton
    async rc_ClickLogin() {

        //Click Login link to navigates to login UI
        await this.lnk_LoginButton.click()
    }

    //Click join buton
    async rc_ClickJoin() {

        //Click join link to navigates to create new screen UI
        await this.lnk_JoinButton.click()
    }
    
    //Verify Login Succuss
    async rc_VerifyLoginSuccess() {

        //Verify that notification icon after a succusfull login
        await expect(this.icn_BellForNotification, 'Login Succsfull').toBeVisible()
    }

    //Click an item (Live in play, Next15,Cricket,Racing,Soccer,Watch and Bet,All Sport) from tob bar
    async rc_ClickAnItemFromTopMenu(ItemName) {
        await this.page.waitForTimeout(5000)
        //click on a item
        switch (ItemName) {
            case "Live":
                await this.lnk_LiveInPlay.click()
                break;
            case "Next":
                await this.lnk_Next15.click()
                break;
            case "Cricket":
                await this.lnk_Cricket.click()
                break;
            case "Racing":
                await this.lnk_Racing.click()
                break;
            case "Soccer":
                await this.lnk_Soccer.click()
                break;
            case "Watch":
                await this.lnk_WatchAndBet.click()
                break;
            case "All":
                await this.lnk_AllSport.click()
                break;
            default:
                console.log("Entered item name is incorrect & Please enter a correct item name to click")
        }
    }
     
    //Expand or Collaps All Racing icon in left menu
    async rc_ExpandOrCollapseAllRacingFromLeftMenu() {
    }

     //Click on the first sport from popular section
    async rc_ClickOnFirstSportFromPopularSports() {
        await this.page.waitForTimeout(5000)    
        //Click place bet button
        await this.lnk_FirstMatchInPopularSports.click()       
    }

    //Click on the first race from popular racing
    async rc_ClickOnFirstRaceFromPopularRacing() {
        await this.page.waitForTimeout(5000)    
        //Click place bet button
        await this.lnk_FirstRaceInPopularRacing.click()       
    }

    //Click on the odd button of first selection from popular racing
    async rc_ClickOnOddButtonFromFirsSelectionFromPopularRacing() {
        await this.page.waitForTimeout(5000)    
        //Click place bet button
        await this.btn_FirstOddInPopularRacing.click()        
    }

    //Select a Racing type from All Racing in left menu
    async rc_SelectARacingTypeFromAllRacing(raceType) {
        await this.page.waitForTimeout(5000)
        //click on a item
        switch (raceType) {
            case "Horse":
                await this.lnk_HorseRacingInAllRacing.click()
                break;
            case "Grey":
                await this.lnk_GreyhoundRacingInAllRacing.click()
                break;
            case "Harness":
                await this.lnk_HarnessRacingInAllRacing.click()
                break;
            case "Kiron":
                await this.lnk_KiranVirrualRacingInAllRacing.click()
                break;
            default:
                console.log("Entered race type is incorrect & Please enter a correct race type to click")
        }
    }

    //Expand or Collaps All Sports icon in left menu
    async rc_ExpandOrCollapseAllSportsFromLeftMenu() {

    }

    //Select a sport type from All Sport left menu
    async rc_SelectASportTypeFromAllSport(sportName) {

        await this.page.waitForTimeout(5000)
        //click on a item
        switch (sportName) {
            case "Basketball":
                await this.lnk_BasketballInAllSports.click()
                break;
            case "Boxing":
                await this.lnk_BoxingInAllSports.click()
                break;
            case "Cricket":
                await this.lnk_CricketInAllSports.click()
                break;
            case "Formula":
                await this.lnk_Formula1InAllSports.click()
                break;
            case "Rugby":
                await this.lnk_RugbyInAllSports.click()
                break;
            case "Soccer":
                await this.lnk_SoccerInAllSports.click()
                break;
            case "Tennis":
                await this.lnk_TennisInAllSports.click()
                break;
            default:
                console.log("Entered race type is incorrect & Please enter a correct race type to click")
        }
        await this.page.waitForTimeout(5000)

    }

    //Enter Win,Place or Stake bet amount
    async rc_EnterWinPlaceOrStakeBetAmoumt(betType, betAmount) {
      //  await this.page.waitForTimeout(5000)

        //Enter bet as Win amount
        if (betType === "Win") {
            //Enter win amount
            await this.tf_Win.fill(betAmount)
        }

        //Enter bet as place amount
        else if (betType === "Place") {
            await this.tf_Place.fill(betAmount)
        }

        //Enter bet as Stake amount
        else if (betType === "Stake") {
            await this.tf_Stake.fill(betAmount)
        }

        //Enter bet as win and place
        else if (betType === "WinAndPlace") {
            await this.tf_Win.fill(betAmount)
            await this.tf_Place.fill(betAmount)
        }

        await this.page.waitForTimeout(2000)

    }  

    //Enter Win or place amount for single or double in multiple options
    async rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions(selctionType,betType, betAmount) {
        await this.page.waitForTimeout(5000)

        if(selctionType==="Single"){
             //Enter bet as Win amount
            if (betType === "Win") {
            //Enter win amount
                await this.tf_WinSingleInMultipleOptions.fill(betAmount)
                }

            //Enter bet as place amount
            else if (betType === "Place") {
                await this.tf_PlaceSingleInMultipleOptions.fill(betAmount)
                }

            //Enter bet as win and place
            else if (betType === "WinAndPlace") {
                await this.tf_WinSingleInMultipleOptions.fill(betAmount)
                await this.tf_WinSingleInMultipleOptions.fill(betAmount)
                }

        }
        else if (selctionType==="Double"){
            //Enter bet as Win amount
            if (betType === "Win") {
                //Enter win amount
                    await this.tf_WinDoubleInMultipleOptions.fill(betAmount)
                 }
    
                //Enter bet as place amount
                else if (betType === "Place") {
                    await this.tf_PlaceDoubleInMultipleOptions.fill(betAmount)
                }
    
                //Enter bet as win and place
                else if (betType === "WinAndPlace") {
                    await this.tf_WinDoubleInMultipleOptions.fill(betAmount)
                    await this.tf_WinDoubleInMultipleOptions.fill(betAmount)
                }
        }

        else{
            console.log("Please enter single or Doble as selection type")
        }

       

    }  
    
    //Click on Each Way & Place a Bet
    async rc_EnterAStakeViaEachWay(betAmount) {
        await this.page.waitForTimeout(5000)

        //Click on Each way chech box
        await this.chk_EachWay.click({ force: true })
        
        //Enter win amount
        await this.tf_Win.fill(betAmount)            

    }    

    //Click Place Bet button
    async rc_ClickPlaceBet() {

        //Click place bet button
        await this.btn_PlaceBet.click()
        await this.page.waitForTimeout(5000)
        //Check whether there is an odd update after clicking place bet
        const OddUpdatedStatus=await this.msg_OddValueHasBeenUpdated.count() 
        console.log(OddUpdatedStatus)
        
        if(OddUpdatedStatus==0){
            console.log("Odd is not updated while placing bet")  
        }
        if(OddUpdatedStatus==1){    
            const OddUpdated=1  
            console.log("Before While")   
                  
            while(OddUpdated<1){ 
                console.log("=========Odd is updated while placing bet")               
                await this.page.waitForTimeout(2000)
               // await this.btn_Clear.click()
                await this.btn_PlaceBet.click()
                OddUpdated=await this.msg_OddValueHasBeenUpdated.count()                 
            }         
        }        
    }

    //Verify minimum slip amount validation
    async rc_VerifyMinimumSlipAmountValidation() {

        await this.page.waitForTimeout(3000)
        //Verify minimum slip amount validation
        expect(this.msg_MinimumSlipAmountShouldBe, 'Validation message is showing as Minimum Slip Amount should be LKR 30.00').toHaveText("Minimum Slip Amount should be LKR 30.00")
    }

    //Verify minimum stake value validation
    async rc_VerifyMinimumStakeValueValidation() {

        await this.page.waitForTimeout(3000)
        //Verify minimum stake value validation
        expect(this.msg_MinimumStakeValueShouldBe, 'Validation message is showing as Minimum Stake Value should be LKR 10.00').toHaveText("Minimum Stake Value should be LKR 10.00")
    }

    //Verify betss success message
    async rc_VerifyBettsSuccessMessage() {

        await this.page.waitForTimeout(5000)
        //Verify betss success message
        expect(this.msg_BetssSuccessfullyPlaced, 'Bet is places successfully & success message is showing').toContainText('Successfully Placed')
        await this.page.waitForTimeout(3000)
    }

    //Verify message when trying to bet without logging
    async rc_VerifyValidationMessageWhenBetingWitohutLoging() {      

        //Verify the validation message
        await expect(this.msg_YouHaveToLogInToSystemBeforePlacingABet, 'Unable to bet without login').toBeVisible()
    }
    
    //Store the availble credit balance 
    async rc_StoreCreditBalance(){

        await this.page.waitForTimeout(5000)
        //Retrive & Store value of credit
        const creditBalance =await this.val_CreditBalance.innerText()
        //Remove the , from balance
        const replacedVal=creditBalance.replace(",","")
        //Remove the decimal values
        const valWithoutdecimal = Math.trunc(replacedVal).toString()
        //Store as a integer
      //  const valueCreditBalance=parseInt(valWithoutdecimal)
        return valWithoutdecimal          
    }   
    
    //Verify validation message when there is no Sufficient balance
    async rc_VerifyValidationMessageWhenThereIsNoSufficientBalance() {      

        //Verify the validation message
        await expect(this.msg_InsufficientBalance, 'You can not place this bet, Insufficient Balance ').toBeVisible()
    }
     
    //Verify the credit balance is increased after a deposit
    async rc_VerifyCreditBalanceIsIncreasedAfterADeposit(beforeAmount,afterAmount) {         
     
        //Get the credit balance before deposit + deposited amount
        const balanceAfterdepost=parseInt(beforeAmount)+5000
        //Sotre as an interger
        const balanceAfterDeposit=parseInt(afterAmount)
        //Verify that before ammout + deposited amount is equal to afer amount
        expect(balanceAfterdepost).toBe(balanceAfterDeposit)
    }

    //Store the availble credit balance 
    async rc_ClickBetSPOrOddValue(){

        //Retrive & Store value of credit
        const creditBalance =await this.val_CreditBalance.innerText()
        //Remove the , from balance
        const replacedVal=creditBalance.replace(",","")
        //Remove the decimal values
        const valWithoutdecimal = Math.trunc(replacedVal).toString()
        //Store as a integer
      //  const valueCreditBalance=parseInt(valWithoutdecimal)
        return valWithoutdecimal          
    }  
    
    //Verify the validation message when place statke is gratere than win
    async rc_VerifyValidationWhenPlaceIsGraterThanWin() {

        await this.page.waitForTimeout(3000)
        //Verify minimum stake value validation
        expect(this.msg_WinStakeShouldBeGreaterThanOrEqualToPlaceStake, 'Validation message is showing as Win stake should be greater than or equal to Place stake').toHaveText("Win stake should be greater than or equal to Place stake")
    }

    //Verify the validation message when place only bet is placed
    async rc_VerifyValidationWhenPlaceOnlyBetIsPlaced() {

        await this.page.waitForTimeout(3000)
        //Verify minimum stake value validation
        expect(this.msg_YouAreNotAllowedToPlaceBetsWithoutWinStake, 'Validation message is showing as You are not allowed to place bets without win stake').toHaveText("You are not allowed to place bets without win stake")
    }

    //Store the Slip ID & Clik OK from from success message after placing a bet       
    async rc_StoreSlipIDAndClickOK(){

        await this.page.waitForTimeout(5000)
        //Store the slip ID
        const slipId =await this.msg_BetssSuccessfullyPlaced.innerText()
        //Remove the characters and special characters from inner text
        const slipIdAfterRemovingCharacters=slipId.replace(/[^0-9]/g, "") 
        await this.btn_OKBetssSuccessPopUp.click()       
        return slipIdAfterRemovingCharacters 
        //Click OK from success message
                
    }  
    
    //Click an item from righ menu after clicking profil icon to click on My Bets, My Transaction
    async rc_ClickAnItemFromRighMenu(ItemName){

        await this.page.waitForTimeout(2000)
        //click on a item
        switch (ItemName) {
            case "Bets":
                await this.lnk_MyBets.click()
                break;
            case "Transactions":
                await this.lnk_MyTransctions.click()
                break;
            case "Withdraw":
                await this.lnk_Withdraw.click()
                break;
            case "Deposit":
                await this.lnk_Deposit.click()
                break;
            case "Bank":
                await this.lnk_MyBankAccount.click()
                break;
            case "Bonus":
                await this.lnk_Bonus.click()
                break;            
            default:
                console.log("Entered item name is incorrect & Please enter a correct item name to click")
        }  
    } 

    //Verify the bet details in My Bet section
    async rc_VerifyBetDetailsInMyBetsSection(splipId,totalStake,market,stake) {

        await this.page.waitForTimeout(3000)
        //Store the slip id
        const slipIdInMyBet =await this.val_SlilpId.innerText()
        //Remove the characters and special characters from inner text
        const slipIdAfterRemovingCharacters=slipIdInMyBet.replace(/[^0-9]/g,"") 
        //Verify the slip id is correct
        expect(slipIdAfterRemovingCharacters).toBe(splipId)
        //Verify that total stake is correct
        //Store the total stake
        const totStake=await this.val_TotalStake.innerText()
        //Removeing LKR & decimal values
        const updatedStatke=totStake.replace(/[^0-9]/g, "")
        const stakeWithoutDecimal=updatedStatke.substring(0, updatedStatke.length - 2);
        //Verify total stake is correct
        expect(stakeWithoutDecimal).toBe(totalStake)
        //Verify that toatl return is zero
        const totReturn=await this.val_TotalReturn.innerText()
        const updatedTotReturn=totReturn.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotReturn)).toBe(0)
        //Click on expand icon
        await this.btn_FirstExpand.click()
        await this.page.waitForTimeout(3000)
        //Verify market is correct
        const marketName=await this.val_Market.innerText()
        expect(marketName).toBe(market)
        //Verify the stake is correct
        const stakeValue=await this.val_Stake.innerText()
        const updatedStake=stakeValue.replace(/[^0-9]/g,"").slice(0,2)
        expect(updatedStake).toBe(stake)
        //Verify that toatl payout is zero
        const totPayout=await this.val_Payout.innerText()
        const updatedTotPayout=totPayout.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotPayout)).toBe(0)
    }

    //Verify the bet details in My Bet section for soccer
    async rc_VerifyBetDetailsInMyBetsSectionForSoccer(splipId,totalStake,stake) {

        await this.page.waitForTimeout(3000)
        //Store the slip id
        const slipIdInMyBet =await this.val_SlilpId.innerText()
        //Remove the characters and special characters from inner text
        const slipIdAfterRemovingCharacters=slipIdInMyBet.replace(/[^0-9]/g,"") 
        //Verify the slip id is correct
        expect(slipIdAfterRemovingCharacters).toBe(splipId)
        //Verify that total stake is correct
        //Store the total stake
        const totStake=await this.val_TotalStake.innerText()
        //Removeing LKR & decimal values
        const updatedStatke=totStake.replace(/[^0-9]/g, "")
        const stakeWithoutDecimal=updatedStatke.substring(0, updatedStatke.length - 2);
        //Verify total stake is correct
        expect(stakeWithoutDecimal).toBe(totalStake)
        //Verify that toatl return is zero
        const totReturn=await this.val_TotalReturn.innerText()
        const updatedTotReturn=totReturn.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotReturn)).toBe(0)
        //Click on expand icon
        await this.btn_FirstExpand.click()
        await this.page.waitForTimeout(3000)
       /*  //Verify market is correct
        const marketName=await this.val_Market.innerText()
        expect(marketName).toBe(market) */
        //Verify the stake is correct
        const stakeValue=await this.val_Stake.innerText()
        const updatedStake=stakeValue.replace(/[^0-9]/g,"").slice(0,2)
        expect(updatedStake).toBe(stake)
        //Verify that toatl payout is zero
        const totPayout=await this.val_Payout.innerText()
        const updatedTotPayout=totPayout.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotPayout)).toBe(0)
    }

    //Verify the bet details in My Bet section for double win bet
    async rc_VerifyBetDetailsInMyBetsSectionForWinDoubleBet(splipId,totalStake,market,stake) {

        await this.page.waitForTimeout(3000)
        //Store the slip id
        const slipIdInMyBet =await this.val_SlilpId.innerText()
        //Remove the characters and special characters from inner text
        const slipIdAfterRemovingCharacters=slipIdInMyBet.replace(/[^0-9]/g,"") 
        //Verify the slip id is correct
        expect(slipIdAfterRemovingCharacters).toBe(splipId)
        //Verify that total stake is correct
        //Store the total stake
        const totStake=await this.val_TotalStake.innerText()
        //Removeing LKR & decimal values
        const updatedStatke=totStake.replace(/[^0-9]/g, "")
        const stakeWithoutDecimal=updatedStatke.substring(0, updatedStatke.length - 2);
        //Verify total stake is correct
        expect(stakeWithoutDecimal).toBe(totalStake)
        //Verify that toatl return is zero
        const totReturn=await this.val_TotalReturn.innerText()
        const updatedTotReturn=totReturn.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotReturn)).toBe(0)
        //Click on expand icon
        await this.btn_FirstExpand.click()
        await this.page.waitForTimeout(3000)
        //Verify market is correct
        const marketName=await this.val_Market.innerText()
        expect(marketName).toBe(market)
        //Verify the stake is correct
        const stakeValue=await this.val_Stake.innerText()
        const updatedStake=stakeValue.replace(/[^0-9]/g,"").slice(0,2)
        expect(updatedStake).toBe(stake)
        //Verify that toatl payout is zero
        const totPayout=await this.val_PayoutForWinDouble.innerText()
        const updatedTotPayout=totPayout.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotPayout)).toBe(0)
    }

    //Verify the bet details in My Bet section
    async rc_VerifyBetDetailsWhenBettinsForMultipleSelection(market,stake) {
      
        //Verify market is correct for second selection
        const marketName=await this.val_MarketForSecondSelection.innerText()
        expect(marketName).toBe(market)
        //Verify the stake is correct
        const stakeValue=await this.val_StakeForSecondSelection.innerText()
        const updatedStake=stakeValue.replace(/[^0-9]/g,"").slice(0,2)
        expect(updatedStake).toBe(stake)
        //Verify that toatl payout is zero
        const totPayout=await this.val_PayoutForSecondSelection.innerText()
        const updatedTotPayout=totPayout.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotPayout)).toBe(0)
    }

    //Verify the bet details in My Bet section for outrights games
    async rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(splipId,totalStake,stake) {

        await this.page.waitForTimeout(3000)
        //Store the slip id
        const slipIdInMyBet =await this.val_SlilpId.innerText()
        //Remove the characters and special characters from inner text
        const slipIdAfterRemovingCharacters=slipIdInMyBet.replace(/[^0-9]/g,"") 
        //Verify the slip id is correct
        expect(slipIdAfterRemovingCharacters).toBe(splipId)
        //Verify that total stake is correct
        //Store the total stake
        const totStake=await this.val_TotalStake.innerText()
        //Removeing LKR & decimal values
        const updatedStatke=totStake.replace(/[^0-9]/g, "")
        const stakeWithoutDecimal=updatedStatke.substring(0, updatedStatke.length - 2);
        //Verify total stake is correct
        expect(stakeWithoutDecimal).toBe(totalStake)
        //Verify that toatl return is zero
        const totReturn=await this.val_TotalReturn.innerText()
        const updatedTotReturn=totReturn.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotReturn)).toBe(0)
        //Click on expand icon
        await this.btn_FirstExpand.click()
        await this.page.waitForTimeout(3000)        
        //Verify the stake is correct
        const stakeValue=await this.val_Stake.innerText()
        const updatedStake=stakeValue.replace(/[^0-9]/g,"").slice(0,2)
        expect(updatedStake).toBe(stake)
        //Verify that toatl payout is zero
        const totPayout=await this.val_PayoutForWinDouble.innerText()
        const updatedTotPayout=totPayout.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotPayout)).toBe(0)
    }

    //Verify the bet details in My Bet section for double win bet for cricket sports
    async rc_VerifyBetDetailsInMyBetsSectionForWinDoubleBetsForCricketSports(splipId,totalStake,stake) {

        await this.page.waitForTimeout(3000)
        //Store the slip id
        const slipIdInMyBet =await this.val_SlilpId.innerText()
        //Remove the characters and special characters from inner text
        const slipIdAfterRemovingCharacters=slipIdInMyBet.replace(/[^0-9]/g,"") 
        //Verify the slip id is correct
        expect(slipIdAfterRemovingCharacters).toBe(splipId)
        //Verify that total stake is correct
        //Store the total stake
        const totStake=await this.val_TotalStake.innerText()
        //Removeing LKR & decimal values
        const updatedStatke=totStake.replace(/[^0-9]/g, "")
        const stakeWithoutDecimal=updatedStatke.substring(0, updatedStatke.length - 2);
        //Verify total stake is correct
        expect(stakeWithoutDecimal).toBe(totalStake)
        //Verify that toatl return is zero
        const totReturn=await this.val_TotalReturn.innerText()
        const updatedTotReturn=totReturn.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotReturn)).toBe(0)
        //Click on expand icon
        await this.btn_FirstExpand.click()
        await this.page.waitForTimeout(3000)       
        //Verify the stake is correct
        const stakeValue=await this.val_Stake.innerText()
        const updatedStake=stakeValue.replace(/[^0-9]/g,"").slice(0,2)
        expect(updatedStake).toBe(stake)
        //Verify that toatl payout is zero
        const totPayout=await this.val_PayoutForWinDouble.innerText()
        const updatedTotPayout=totPayout.replace(/[^0-9]/g,"").slice(0,1)
        expect(parseInt(updatedTotPayout)).toBe(0)
    }
     
    //Click login profile icon
    async rc_ClickProfileIconAfterLogin() {

        //Click profile icon
        await this.icn_ProfileAfterLogin.click()
    }  
    
    //Verify message when trying to access kiron virtual racing without logging
    async rc_VerifyValidationMessageWhenAccessingKirionVirtualSectionWithoutLoging() {      

        //Verify the validation message
        await expect(this.msg_YouHaveToLogInToTheSystemToAccessKironVirtual, 'Unable to move to kiron virtual without login').toHaveText('You have to log in to the system to access Kiron Virtual.')
    }
      
    //Verify that all the elements are visible in top bar in home page
    async rc_VerifyTopBarEelements() {

        //Verify betss logo is visibled       
        await expect.soft(this.icn_BetssLogo).toBeVisible()
        //Verify that English icon is visible
        await expect.soft(this.icn_Enlish).toBeVisible()
        //Verify that Sinhala icon is visible
        await expect.soft(this.icn_Sinhala).toBeVisible()
        //Verify that Tamil icon is visible
        await expect.soft(this.icn_Tamil).toBeVisible()
        //Verify that profile icon is visible
        await expect.soft(this.icn_Profile).toBeVisible()
        //Verify that Login button is visible when clicking on profile icon
        await this.icn_Profile.click()
        await expect.soft(this.lnk_LoginButton).toBeVisible() 
        //Verify that join button is visible when clicking on profile icon
        await expect.soft(this.lnk_JoinButton).toBeVisible()
        await this.icn_Profile.click()
        //Verify that live in play icon is visible
        await expect.soft(this.icn_LiveInPlay).toBeVisible()
        //Verify that live in play link is visible
        await expect.soft(this.lnk_LiveInPlay).toBeVisible()
        //Verify that Next 15 link is visible
        await expect.soft(this.lnk_Next15).toBeVisible()
        //Verify that Cricket link is visible
        await expect.soft(this.lnk_Cricket).toBeVisible()
        //Verify that soccer link is visible
        await expect.soft(this.lnk_Soccer).toBeVisible()
        //Verify that Watch and bet link is visible
        await expect.soft(this.lnk_WatchAndBet).toBeVisible()
         //Verify that All Sport link is visible
         await expect.soft(this.lnk_AllSport).toBeVisible()

    }  

    //Verify that all the elements are visible in left menu in home page
    async rc_VerifyLeftMenuEelements() {

        //Verify that date and time is correct (To be implemented)     

        //Verify that Popular sport link is visible
        await expect.soft(this.lnk_PopularSports).toBeVisible()
        //Verify that Popular racing link is visible
        await expect.soft(this.lnk_PopularRacing).toBeVisible()
        //Verify that All racing link is visible
        await expect.soft(this.lnk_AllRacing).toBeVisible()
        //Verify that horse racing is available under All Racing
        await expect.soft(this.lnk_HorseRacingInAllRacing).toBeVisible()
        //Verify that greyhound racing is available under All Racing
        await expect.soft(this.lnk_GreyhoundRacingInAllRacing).toBeVisible()
        //Verify that harness racing is available under All Racing
        await expect.soft(this.lnk_HarnessRacingInAllRacing).toBeVisible()
        //Verify that Kiron racing are not visible before login (To be implemented)
        /**To Be Developed */
        //Verify that all sports is visible 
        await expect.soft(this.lnk_AllSportsInLeftmenu).toBeVisible()
        //Verify that basketball is visible under All Sports
        await expect.soft(this.lnk_BasketballInAllSports).toBeVisible()
        //Verify that boxing is visible under All Sports
        await expect.soft(this.lnk_BoxingInAllSports).toBeVisible()
        //Verify that basketball is visible under All Sports
        await expect.soft(this.lnk_CricketInAllSports).toBeVisible()
        //Verify that formula1 is visible under All Sports
        await expect.soft(this.lnk_Formula1InAllSports).toBeVisible()
        //Verify that rugby is visible under All Sports
        await expect.soft(this.lnk_RugbyInAllSports).toBeVisible()
        //Verify that soccer is visible under All Sports
        await expect.soft(this.lnk_SoccerInAllSports).toBeVisible()
        //Verify that tennis is visible under All Sports
        await expect.soft(this.lnk_TennisInAllSports).toBeVisible()
        

    }
    
    //Verify that all the elements are visible in right menu in home page
    async rc_VerifyRightMenuEelements() {
       
        //Verify that bet slip lable is visible
        await expect.soft(this.lbl_BetSlip).toBeVisible()
        //Verify that value near bet slip is zere
        await expect.soft(this.val_BetSlipZero).toHaveText('0');
        //Verify that LKR0 lable is visible
        await expect.soft(this.lbl_LKR0).toBeVisible()
        //Verify that place bet button is visble 
        await expect.soft(this.btn_PlaceBet).toBeVisible()
        //Verify that plac bet button is diabled
        await expect.soft(this.btn_PlaceBet).toBeDisabled()
        //Verify that clear button is visble 
        await expect.soft(this.btn_Clear).toBeVisible()
        //Verify that Bets will be shown...... message is visble 
        await expect.soft(this.lbl_BetsWillBeAdded).toBeVisible()
        //Verify that recent bets link is visble 
        await expect.soft(this.lnk_RecentBets).toBeVisible()
        //Veriy that please join to system ........ message is visible when clicking on recent bets link
        await this.lnk_RecentBets.click()
        await expect.soft(this.lbl_PleaseLoginToSystemInRecentBets).toBeVisible()
        //Veriy that join button is visible when clicking on recent bets link
        await expect.soft(this.btn_JoinInRecentBets).toBeVisible()
        await this.lnk_RecentBets.click()
        //Verify that results link is visble 
        await expect.soft(this.lnk_Results).toBeVisible()
        //Veriy that please join to system ........ message is visible when clicking on results link
        await this.lnk_Results.click()
        await expect.soft(this.lbl_PleaseLoginToSystemInResults).toBeVisible()
        //Veriy that join button is visible when clicking on recent bets link
        await expect.soft(this.btn_JoinInResults).toBeVisible()
        await this.lnk_Results.click()
        //Verify that racing papers link is visble 
        await expect.soft(this.lnk_RacingPapers).toBeVisible()
        //Veriy that please join to system ........ message is visible when clicking on racing papers link
        await this.lnk_RacingPapers.click()
        await expect.soft(this.lbl_PleaseLoginToSystemInRacingPapers).toBeVisible()
        //Veriy that join button is visible when clicking on racing papers bets link
        await expect.soft(this.btn_JoinInRacinRacingPapers).toBeVisible()
        await this.lnk_RacingPapers.click()
        //Verify that news feed visble 
        await expect.soft(this.lnk_NewsFeed).toBeVisible()
        //Verify that racing post image is visible
        await expect.soft(this.img_RacingPost).toBeVisible()
        //Verify that racing post name is visible when houring mouse over the image
        await this.lnk_RacingPapers.mouse.move(0,0)
        await expect.soft(this.lnk_RacingPostWhenHouringMouse).toHaveAttribute("Racing Post")
        //Verify that sporting image is visible
        await expect.soft(this.img_SportingLife).toBeVisible()
        //Verify that racing sporting life name is visible when houring mouse over the image
        await this.img_SportingLife.mouse.move(0,0)        
        await expect.soft(this.lnk_RacingPostWhenHouringMouse).toHaveAttribute("Racing Post")        

    }

    //Click on recent bets
    async rc_ClickRecentBets() {

        await this.page.waitForTimeout(5000)
        //Click profile icon
        await this.lnk_RecentBets.click()    
    }        

    //Verify betss in recent betss
    async rc_VerifyBettsInRecentBetss(slipId) {

        await this.page.waitForTimeout(5000)
       // const sllipID =await this.lnk_FirstBetInRecentBets.innerText()
        //Verify bets is available in recent bets
        expect(this.lnk_FirstBetInRecentBets.innerText()).toContainText(slipId)
        await this.page.waitForTimeout(3000)
    }

    //Click on results
    async rc_ClickResults() {
        await this.page.waitForTimeout(5000)
        //Click result
        await this.lnk_Results.click()  
    }  

    //Verify result page loaded
    async rc_VerifyResultsLoaded() {    

        await this.page.waitForTimeout(5000)
        //Verify that horse racing result is visible in result section
        await expect.soft(this.lnk_HorseRacing).toBeVisible()
        //Verify that greyhound racing result is visible in result section
        await expect.soft(this.lnk_Greyhound).toBeVisible()
        //Verify that cricket result is visible in result section
        await expect.soft(this.lnk_Cricket).toBeVisible()
        //Verify that rugby result is visible in result section
        await expect.soft(this.lnk_Rugby).toBeVisible()
        //Verify that soccer racing result is visible in result section
        await expect.soft(this.lnk_Soccer).toBeVisible()
        //Verify that harness racing result is visible in racing section
        await expect.soft(this.lnk_HarnessRacing).toBeVisible()
        //Verify that kiron virtual racing result is visible in racing section
        await expect.soft(this.lnk_KironVirtualRacing).toBeVisible()
        //Verify that basketball result is visible in sports section
        await expect.soft(this.lnk_BaseketballInSports).toBeVisible()
        //Verify that boxing result is visible in sports section
        await expect.soft(this.lnk_BoxingInSports).toBeVisible()
        //Verify that formula result is visible in sports section
        await expect.soft(this.lnk_Formula1InSports).toBeVisible()
        //Verify that tennis is visible in sports section
        await expect.soft(this.lnk_TennisInSports).toBeVisible()
        //Click horse racing & verify that result are available
        await this.lnk_HorseRacing.click()  
        await this.page.waitForTimeout(3000)
        await expect.soft(this.lnk_FirstResultInHorseRacing).toBeVisible()
        await this.icn_BackButton.click()
        await this.page.waitForTimeout(3000)
        //Click grayhound racing & verify that result are available
        await this.lnk_Greyhound.click()  
        await this.page.waitForTimeout(3000)
        await expect.soft(this.lnk_FirstResultInGrayhoundRacing).toBeVisible()
        await this.icn_BackButton.click()
        await this.page.waitForTimeout(3000)
        //Click cricket & verify that result are available
        await this.lnk_Cricket.click()  
        await this.page.waitForTimeout(3000)
        await expect.soft(this.lnk_FirstResultInCricket).toBeVisible()
        await this.icn_BackButton.click()
        await this.page.waitForTimeout(3000)
        //Click rugby & verify that result are available
        await this.lnk_Rugby.click()  
        await this.page.waitForTimeout(3000)
        await expect.soft(this.lnk_FirstResultInRugby).toBeVisible()
        await this.icn_BackButton.click()
        await this.page.waitForTimeout(3000)
        //Click soccer & verify that result are available
        await this.lnk_Soccer.click()  
        await this.page.waitForTimeout(3000)
        await expect.soft(this.lnk_FirstResultInSoccer).toBeVisible()
        await this.icn_BackButton.click()
        await this.page.waitForTimeout(3000)
        //Click harness racing & verify that result are available
        await this.lnk_HarnessRacing.click() 
        await this.page.waitForTimeout(5000)
        await expect.soft(this.lnk_FirstResultInHarnessRacing).toBeVisible()
        await this.icn_BackButton.click()
        await this.page.waitForTimeout(3000)
        //Click kiron virtual racing & verify that result are available
        await this.lnk_KironVirtualRacing.click()  
        await this.page.waitForTimeout(3000)
        await expect.soft(this.lnk_FirstResultInKironVirtualRacing).toBeVisible()
        await this.icn_BackButton.click()
        await this.page.waitForTimeout(3000)
    }

    //Click racing post or sporting life from news feed
    async rc_ClickRacingPostOrSportingLifeFromNewsFeed(type) {
        await this.page.waitForTimeout(5000)

        if(type==="Racing"){       
            //Mouse hover over an racing post    
            await this.img_RacingPost.hover()
            //Click on racing post
            await this.lnk_RacingPost.click()
        }

        else if(type==="Sporting"){
            //Mouse hover over an sporting post  
            await this.img_SportingLife.hover()
            //Click on sporting post
            await this.lnk_SportingLife.click()
        }        
    }    

    //Verify odd format changing funtionlatiy
    async rc_VerifyOffChangingFuntionality(fractionDecimalStatus) {    

        await this.page.waitForTimeout(5000) 
        //Get the status of fraction radion button        
        const areaCheckedStatus = await this.rdo_Fraction.getAttribute('aria-checked')
        console.log(areaCheckedStatus)    
        if(areaCheckedStatus===true){
        //Verify that odd format is set to praction
        expect(fractionDecimalStatus).toBe("fraction")
        //Click on fraction button
        await this.rdo_Fraction.click()
        //Click ok from success pop up
        await this.btn_OKFromOddFormatChangingSuccessPopup.click()
        //Verify that odd format is set to decimal
        expect(fractionDecimalStatus).toBe("decimal")

        }

        else if(areaCheckedStatus===false){
        //Verify that odd format is set to decimal
        expect(fractionDecimalStatus).toBe("decimal")
         //Click on fraction button
        await this.rdo_Fraction.click()
        //Click ok from success pop up
        await this.btn_OKFromOddFormatChangingSuccessPopup.click()
        //Verify that odd format is set to fraction
        expect(fractionDecimalStatus).toBe("fraction")
            
        }         
           
    }

}


        