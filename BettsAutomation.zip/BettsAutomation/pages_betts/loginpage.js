import { test, expect } from '@playwright/test';

export class LoginPage{

    constructor(page) {

        this.page = page
        
        /* ========Login Section ====================================*/
        this.txt_Username = page.getByPlaceholder("Username")
        this.txt_Password = page.locator("input#Password")
        this.chk_RememberMyLogin=page.locator("input#RememberLogin")
        this.btn_LoginInLoginUI = page.locator("//button[text()='Login']")

    }

    //This is for login
    async rc_Login(Username, Password, RememberMyLoginChecked) {  
        
        //Click Remember My login Checked
        
        if(RememberMyLoginChecked === "Yes"){
            await this.chk_RememberMyLogin.click();
        }
          //Enter username
          await this.txt_Username.fill(Username)

          //Enter password
          await this.txt_Password.fill(Password)
  
          //Click login button
          await this.btn_LoginInLoginUI.click()      
    }

    //Click on Username or Forgot password link
    async rc_ClickForgotUsernameOrPassword() {
    }


}

  