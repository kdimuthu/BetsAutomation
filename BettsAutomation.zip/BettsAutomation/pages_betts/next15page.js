import { test, expect } from '@playwright/test';

export class Next15Page {

    constructor(page) {

        this.page = page

        /* ========All tab================================*/

        this.btn_FirstBetOrSP = page.locator("//div[contains(text(),'All ')]/following::span[@class='mat-button-wrapper'][1]") 
        this.btn_SecondBetOrSP = page.locator("//div[contains(text(),'All ')]/following::div[@role='tabpanel'][1]/descendant::div[@class='ng-star-inserted'][3]/descendant::div[@class='section ng-star-inserted'][1]/descendant::span[@class='mat-button-wrapper'][1]") 
        this.btn_ThirdBetOrSP = page.locator("//div[contains(text(),'All ')]/following::span[@class='mat-button-wrapper'][3]")        
        this.btn_FirstBet = page.locator("//div[contains(text(),'All ')]/following::span[contains(text(),'BET')][1]") 
        this.lst_NumberOfBets = page.locator("//div[contains(text(),'All ')]/following::span[contains(text(),'BET')]")         
        this.btn_FirsSP = page.locator("//div[contains(text(),'All ')]/following::span[contains(text(),'SP')][1]") 
        this.btn_SecondSPForNonFavouriteSelection = page.locator("//div[contains(text(),'All ')]/following::p[not(contains( text(),'FAVOURITE'))][1]/following::span[contains(text(),'SP')][2]") 
        this.btn_ThirdSPForNonFavouriteSelection = page.locator("//div[contains(text(),'All ')]/following::p[not(contains( text(),'FAVOURITE'))][1]/following::span[contains(text(),'SP')][3]") 
        this.btn_FourthSPForNonFavouriteSelection = page.locator("//div[contains(text(),'All ')]/following::p[not(contains( text(),'FAVOURITE'))][1]/following::span[contains(text(),'SP')][4]")         
        this.lbl_NameOfSelectionOfSecondSP=page.locator("//div[contains(text(),'All ')]/following::p[not(contains( text(),'FAVOURITE'))][1]/following::span[contains(text(),'SP')][1]/preceding::p[1]")        
        this.lst_NumberOfSP = page.locator("//div[contains(text(),'All ')]/following::span[contains(text(),'SP')]")
        this.lst_NumberOfBET = page.locator("//div[contains(text(),'All ')]/following::span[contains(text(),'BET')]")
        this.btn_FirstODDValue = page.locator("//div[contains(text(),'All ')]/following::p[contains(text(),'FAVOURITE')][1]/following::span[contains(text(),'.') or contains(text(),'/')][1]")         
        this.icn_RaceCardForSP = page.locator("//div[contains(text(),'All ')]/following::span[contains(text(),'SP')][1]/preceding::img[2]")
        this.icn_RaceCardForBET = page.locator("//div[contains(text(),'All ')]/following::span[contains(text(),'BET')][1]/preceding::img[2]")        
        this.lst_NumberOfOdd = page.locator("//div[contains(text(),'All ')]/following::span[contains(text(),'.')]")
        this.lnk_All = page.locator("//div[contains(text(),'All')]")
        this.lnk_Horse = page.locator("//div[contains(text(),'Horse')]")
        this.lnk_Greyhound = page.locator("//div[contains(text(),'Greyhound')]")
        this.lnk_Harness = page.locator("//div[contains(text(),'Harness')]")
        this.lnk_BoxingAndMMA = page.locator("//div[contains(text(),'Boxing')]")
        this.btn_LeftArrow = page.locator("//div[contains(text(),'All')]/preceding::button[@type='button'][1]")
        this.btn_RightArrow = page.locator("//div[contains(text(),'Harness')]/following::button[@type='button'][1]")
        this.btn_Next = page.locator("//span[contains(text(),'News Feed')]/preceding::button[text()='Next'][5]")
        this.btn_Back = page.locator("//span[contains(text(),'News Feed')]/preceding::button[contains(text(),'Back')][4]")
       
         /* ========Horse tab=====================================*/
        this.icn_FirstHorce = page.locator("//div[contains(text(),'All ')]/following::span[@class='mat-button-wrapper'][1]/preceding::img[contains(@src,'horse')][1]")

        /* ========Greyhound tab===================================*/
        this.icn_FirstGreyhound = page.locator("//div[contains(text(),'Greyhound')]/following::img[contains(@src,'grey')][1]")

        /* ========Harness tab======================================*/
        this.icn_FirstHarness = page.locator("//div[contains(text(),'Harness')]/following::img[contains(@src,'harness')][1]")
        this.msg_NoHarnessAvailable = page.locator("//p[contains(text(),'Harness')]")

        /*========Kiran Virtual tab=================================*/

        /* ========Nuwara Eliya tab=================================*/

        /* ========Race Card=========================================*/
        this.btn_WinOrPlace=page.locator("//div[text()='Win or Place']")
        this.btn_WinOrPlace=page.locator("//div[text()='Forecast']")
        this.btn_Tricast=page.locator("//div[text()='Tricast']")
        this.btn_Quinella=page.locator("//div[text()='Quinella']")
        this.btn_Exacta=page.locator("//div[text()='Exacta']")
        this.btn_Trio=page.locator("//div[text()='Trio']")
        this.btn_Trifecta=page.locator("//div[text()='Trifecta']")
        this.btn_First4=page.locator("//div[text()='First 4']")

        /*======= Forrecast =========================================*/
        this.rdo_1stOfFirstSelection=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][1]") 
        this.rdo_2ndOfFirstSelection=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][2]")         
        this.chk_AnyOfFirstSelection=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='checkbox'][1]") 
        this.rdo_1stOfSecondSelection=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][3]") 
        this.rdo_2ndOfSecondSelection=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][4]")                
        this.chk_AnyOfSecondSelection=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='checkbox'][2]")     
        this.rdo_1stOfThirdSelection=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][5]") 
        this.rdo_2ndOfThirdSelection=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][6]")   
        this.rdo_3rdOfThirdSelection=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][9]")              
        this.chk_AnyOfThirdSelection=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='checkbox'][3]")
             
        /*======= Tricast =========================================*/
        this.rdo_1stOfFirstSelectionInTricast=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][1]")
        this.rdo_2ndOfFirstSelectionInTricast=page.locator("")
        this.chk_AnyOfFirstSelectionInTricast=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='checkbox'][1]")
        this.rdo_1stOfSecondSelectionInTricast=page.locator("")
        this.rdo_2ndOfSecondSelectionInTricast=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][5]")
        this.chk_AnyOfSecondSelectionInTricast=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='checkbox'][2]")
        this.rdo_3rdOfThirdSelectionInTricast=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][9]")
        this.rdo_4thOfFourthSelectionInTricast=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][13]")       
        this.rdo_1stOfThirdSelectionInTricast=page.locator("")
        this.chk_AnyOfThirdSelectionInTricast=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='checkbox'][3]")
        this.chk_AnyOfFourthSelectionInTricast=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='checkbox'][4]")

        /*======= First 4 =========================================*/
        this.rdo_1stOfFirstSelectionInFirst4=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][1]")
        this.rdo_2ndOfSecondSelectionInFirst4=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][6]")
        this.rdo_3rdOfThirdSelectionInFirst4=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][11]")
        this.rdo_4thOfFourthSelectionInFirst4=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][16]")
        this.chk_AnyOfFourthSelectionInFirst4=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='checkbox'][4]")
        
        /** ==================Trio============================== */
        this.rdo_2ndOfSecondSelectionInTrio=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][5]") 
        this.rdo_3rdOfThirdSelectionInTrio=page.locator("//div[contains(text(),'Win or ')]/following::input[@type='radio'][9]")   
        
        /**==========Common======================================= */
        this.btn_AddToBetSlip=page.locator("//span[contains(text(),'ADD')]") 

    }

    //Click on a racing type
    async rc_ClickOnARacingType(raceType) {
        //click on a item
        switch (raceType) {
            case "All":
                await this.lnk_All.click()
                break;
            case "Horse":
                await this.lnk_Horse.click()
                break;
            case "Greyhound":
                await this.lnk_Greyhound.click()
            // await this.page.waitForTimeout(5000)
                break;
            case "Harness":
                await this.lnk_Harness.click()
                break;
            case "Boxing":
                await this.lnk_BoxingAndMMA.click()
                break;            
            default:
                console.log("Entered race type is incorrect & Please enter a correct race type to click")
        }

    }

    //Click on a left or right arrow
    async rc_LeftOrRightArrow(leftOrRight) {
        if(leftOrRight=="Left"){
            await this.btn_LeftArrow.click()
        }
        else{
            await this.btn_RightArrow.click() 
        }

    }

    //Click Next or Back button
    async rc_NextOrBack(nextOrBack) {
    }

    //Click a Bet button of available races from All tab
    async rc_ClickBetOrSPButtonOfAGivenRaceNumber(raceNumber) {
        
        await this.page.waitForTimeout(5000)
        //Click on Bet button of first race
        if(raceNumber==1){
            await this.btn_FirstBetOrSP.click()
        }
        //Click on Bet button of second race
        else if(raceNumber==2){
            await this.btn_SecondBetOrSP.click()
        }
        //Click on Bet button of third race
        else if(raceNumber==3){
            await this.btn_ThirdBetOrSP.click()
        }
    }  
    
    //Click on first bet, sp or odd button
    async rc_ClickOnBetSPOrOddButton(type) {       
        
        await this.page.waitForTimeout(5000)
        //Get the number of races with Bets
      // const betsCount = await this.lst_NumberOfBets.count()       
        
        if(type==="BET"){
            //Click on the first Bet button
            await this.btn_FirstBet.click()
        }
            
        //Get the number of races with SP
      //  const spCount = await this.lst_NumberOfSP.count()        
        if(type ==="SP"){
            //Click on the first SP button
            await this.btn_FirsSP.click()
        }
        /* else if (spCount==0){
            await this.btn_Next.click()            
            for(let i=0;i<4;i++){
                spCount = await this.lst_NumberOfSP.count()
                if(spCount==0){
                    //Click next button when there are no ODD
                    await this.btn_Next.click()                    
                }
                else{
                    await this.btn_FirsSP.click()
                    break
                }
            }             
        }   */
        //Get the number of races with Odd values

       // const oddCount = await this.lst_NumberOfOdd.count()        
        if( type ==="Odd"){
            //Click on the first ODD button
            await this.btn_FirstODDValue.click()
        }
        /* else if (oddCount==0){
            await this.btn_Next.click()            
            for(let i=0;i<4;i++){
                oddCount = await this.lst_NumberOfOdd.count()
                if(oddCount==0){
                    //Click next button when there are no ODD
                    await this.btn_Next.click()                   
                }
                else{
                    await this.btn_FirstODDValue.click()  
                    break
                }
            }             
        }   */
    }
    
    //Click on SP button which is not a Favourite selection to click both win & place
    async rc_ClickOnSPOnNonFavouriteSelectionToGetWinAndPlace() {       
        
        await this.page.waitForTimeout(5000)
       
        //Get the number of races with SP
        const spCount = await this.lst_NumberOfSP.count()        
        if(spCount!=0){
        //Retrive & Store value of second SP button
        const selectionName =await this.lbl_NameOfSelectionOfSecondSP.innerText()
        if(selectionName=="FAVOURITE"){
        //Click on the second SP button
            await this.btn_SecondSPForNonFavouriteSelection.click()
        }
        else{
        //Click on the third SP button
            await this.btn_ThirdSPForNonFavouriteSelection.click()
        }             
        }                
    }  
    
    //Verify that horse races are showing in horce tab
    async rc_VerifyHorseRacesAreShowingInHorceTab() {
        await expect(this.icn_FirstHorce, 'Horces races are visible in Horce tab').toBeVisible()   

    }

    //Verify that greyhound races are showing in greyhound tab
    async rc_VerifyGreyhoundRacesAreShowingInGreyhoundTab() {
        await expect(this.icn_FirstGreyhound, 'Greyhound races are visible in Horce tab').toBeVisible()   

    }

    //Verify that harness races are showing in harncess tab
    async rc_VerifyHarnessRacesAreShowingInHarnessTab() {
        await this.page.waitForTimeout(5000)
        const statusFirstHarness = await this.icn_FirstHarness.count();
        if(statusFirstHarness!=0){
            await expect(this.icn_FirstHarness, 'Harness races are visible in Horce tab').toBeVisible() 
        }
        else{
            await expect(this.msg_NoHarnessAvailable, 'No Harness races').toBeVisible() 
        }
    }  
    
    //Click on ... icon & navigates to racecard for SP 
    async rc_NavigatesToRaceCardForSP() {       
        
        await this.page.waitForTimeout(5000)       
        //Get the number of SP in page
        const spCount = await this.lst_NumberOfSP.count()        
        if(spCount!=0){
            //Click on the first SP button
            await this.icn_RaceCardForSP.click()
        }        
        else if (spCount==0){
            await this.btn_Next.click()            
            for(let i=0;i<4;i++){
                spCount = await this.lst_NumberOfSP.count()
                if(spCount==0){
                    //Click next button when there are no SP
                    await this.btn_Next.click()                    
                }
                else{
                    await this.icn_RaceCardForSP.click() 
                    break
                }
            }             
        }  
    }

    //Click on ... icon & navigates to racecard using Bet button 
     async rc_NavigatesToRaceCardUsingBET() {       
        
        await this.page.waitForTimeout(5000)       
        //Get the number of BET in page
        const spCount = await this.lst_NumberOfBET.count()        
        if(spCount!=0){
            //Click on the first SP button
            await this.icn_RaceCardForBET.click()
        }        
        else if (spCount==0){
            await this.btn_Next.click()            
            for(let i=0;i<4;i++){
                spCount = await this.lst_NumberOfBET.count()
                if(spCount==0){
                    //Click next button when there are no SP
                    await this.btn_Next.click()                    
                }
                else{
                    await this.icn_RaceCardForBET.click() 
                    break
                }
            }             
        }  
    }

    //Click different market types from a race card
    async rc_ClickAMarketFromRAceCard(marketType) {
        await this.page.waitForTimeout(5000)
        //click on a item
        switch (marketType) {
            case "WinOrPlace":
                await this.btn_WinOrPlace.click()
                break;
            case "Forecast":
                await this.btn_WinOrPlace.click()
                break;
            case "Tricast":
                await this.btn_Tricast.click()
                break;
            case "Quinella":
                await this.btn_Quinella.click()
                break;
            case "Exacta":
                await this.btn_Exacta.click()
                break;
            case "Trio":
                await this.btn_Trio.click()
                break;
            case "Trifecta":
                await this.btn_Trifecta.click()
                break;
            case "First 4":
                await this.btn_First4.click()
                break;                 
            default:
                console.log("Entered market type is incorrect & Please enter a correct market name to click")
        }
    }

    //Select an option (1st,2nd,3rd,4th,Any) from selection
    async rc_SelectAnOptionFromSelection(selectionNumber,option) {
        await this.page.waitForTimeout(1000)

        if(selectionNumber==1){
            if(option==="1st"){
            //Click on a 1st option in selection 1
            await this.rdo_1stOfFirstSelection.click({ force: true })
            }
            else if(option==="2nd"){
            //Click on a 2nd option in selection 1
            await this.rdo_2ndOfFirstSelection.click({ force: true })
            }
            else if(option==="Any"){
            //Click on a Any option in selection 1
            await this.chk_AnyOfFirstSelection.click({ force: true })
            }
        }
        else if(selectionNumber==2){
            if(option==="1st"){
            //Click on a 1st option in selection 2
            await this.rdo_1stOfSecondSelection.click({ force: true }) 
            }  
            else if(option==="2nd"){
            //Click on a 2nd option in selection 2
            await this.rdo_2ndOfSecondSelection.click({ force: true })
            }
            else if(option==="3rd"){
            //Click on a 3rd option in selection 3
            await this.rdo_3rdOfThirdSelection.click({ force: true })
            }
            else if(option==="Any"){
            //Click on a Any option in selection 2
            await this.chk_AnyOfSecondSelection.click({ force: true })
            }    
        }
        else if(selectionNumber==3){
            if(option==="1st"){
            //Click on a 1st option in selection 3
            await this.rdo_1stOfThirdSelection.click({ force: true }) 
            }  
            else if(option==="2nd"){
            //Click on a 2nd option in selection 3
            await this.rdo_2ndOfThirdSelection.click({ force: true })
            }
            else if(option==="3rd"){
            //Click on a 3rd option in selection 3
            await this.rdo_3rdOfThirdSelection.click({ force: true })
            }               
            else if(option==="Any"){
            //Click on a Any option in selection 2
            await this.chk_AnyOfThirdSelection.click({ force: true })
            }    
        }
                
    }

    //Select an option (1st,2nd,3rd,4th,Any) from selection for Tricase
    async rc_SelectAnOptionFromSelectionForTricasst(selectionNumber,option) {
        

        if(selectionNumber==1){
            if(option==="1st"){
                //Click on a 1st option in selection 1
                await this.rdo_1stOfFirstSelectionInTricast.click({ force: true })
            }
            else if(option==="2nd"){
                //Click on a 2nd option in selection 1
                await this.rdo_2ndOfFirstSelectionInTricast.click({ force: true })               
            }
            else if(option==="Any"){
                //Click on a Any option in selection 1
                await this.chk_AnyOfFirstSelectionInTricast.click({ force: true })                
            }
        }
        else if(selectionNumber==2){
            if(option==="1st"){
                //Click on a 1st option in selection 2            
            }  
            else if(option==="2nd"){
                //Click on a 2nd option in selection 2
            await this.rdo_2ndOfSecondSelectionInTricast.click({ force: true })
            } 
            else if(option==="Any"){
                //Click on a Any option in selection 2
                await this.chk_AnyOfSecondSelectionInTricast.click({ force: true }) 
                
            }    
        }
        else if(selectionNumber==3){
            if(option==="1st"){
                //Click on a 1st option in selection 3            
            }  
            else if(option==="2nd"){
                //Click on a 2nd option in selection 3           
            }             
            else if(option==="3rd"){
                //Click on a 3rd option in selection 3
                await this.rdo_3rdOfThirdSelectionInTricast.click({ force: true })
            }
            else if(option==="Any"){
                //Click on a Any option in selection 3
                await this.chk_AnyOfThirdSelectionInTricast.click({ force: true })                 
            }     
        }  
        else if(selectionNumber==4){
            if(option==="1st"){
                //Click on a 1st option in selection 4            
            }  
            else if(option==="2nd"){
                //Click on a 2nd option in selection 4           
            }             
            else if(option==="3rd"){
                //Click on a 3rd option in selection 4
                await this.rdo_3rdOfThirdSelectionInTricast.click({ force: true })
            }
            else if(option==="4th"){
                //Click on a 3rd option in selection 4
                await this.rdo_4thOfFourthSelectionInTricast.click({ force: true })
            }
            else if(option==="Any"){
                //Click on a Any option in selection 4
                await this.chk_AnyOfFourthSelectionInTricast.click({ force: true })                 
            }     
        } 
        await this.page.waitForTimeout(1000)             
    }

    //Select an option (1st,2nd,3rd,4th,Any) from selection for First 4
    async rc_SelectAnOptionFromSelectionForFirst4(selectionNumber,option) {
        

        if(selectionNumber==1){
            if(option==="1st"){
                //Click on a 1st option in selection 1
                await this.rdo_1stOfFirstSelectionInFirst4.click({ force: true })
            }
            else if(option==="2nd"){
                //Click on a 2nd option in selection 1
                              
            }
            else if(option==="Any"){
                //Click on a Any option in selection 1
                await this.chk_AnyOfFirstSelectionInTricast.click({ force: true }) 
                              
            }
        }
        else if(selectionNumber==2){
            if(option==="1st"){
                //Click on a 1st option in selection 2            
            }  
            else if(option==="2nd"){
                //Click on a 2nd option in selection 2
            await this.rdo_2ndOfSecondSelectionInFirst4.click({ force: true })
            } 
            else if(option==="Any"){
                //Click on a Any option in selection 2
                await this.chk_AnyOfSecondSelectionInTricast.click({ force: true }) 
                
            }    
        }
        else if(selectionNumber==3){
            if(option==="1st"){
                //Click on a 1st option in selection 3            
            }  
            else if(option==="2nd"){
                //Click on a 2nd option in selection 3           
            }             
            else if(option==="3rd"){
                //Click on a 3rd option in selection 3
                await this.rdo_3rdOfThirdSelectionInFirst4.click({ force: true })
            }
            else if(option==="Any"){
                //Click on a Any option in selection 3
                await this.chk_AnyOfThirdSelectionInTricast.click({ force: true })                 
            }     
        }  
        else if(selectionNumber==4){
            if(option==="1st"){
                //Click on a 1st option in selection 4            
            }  
            else if(option==="2nd"){
                //Click on a 2nd option in selection 4           
            }             
            else if(option==="3rd"){
                //Click on a 3rd option in selection 4
                
            }
            else if(option==="4th"){
                //Click on a 4th option in selection 4
                await this.rdo_4thOfFourthSelectionInFirst4.click({ force: true })
            }
            else if(option==="Any"){
                //Click on a Any option in selection 4
                await this.chk_AnyOfFourthSelectionInFirst4.click({ force: true })                 
            }     
        } 
      //  await this.page.waitForTimeout(1000)             
    }

    //Select an option (1st,2nd,3rd) from selection for Trio
    async rc_SelectAnOptionFromSelectionForTrio(selectionNumber,option) {        

        if(selectionNumber==1){
            if(option==="1st"){
                //Click on a 1st option in selection 1
                await this.rdo_1stOfFirstSelection.click({ force: true })
            }
            else if(option==="2nd"){
                //Click on a 2nd option in selection 1
                              
            }
            else if(option==="Any"){
                //Click on a Any option in selection 1
                await this.chk_AnyOfFirstSelectionInTricast.click({ force: true }) 
                              
            }
        }
        else if(selectionNumber==2){
            if(option==="1st"){
                //Click on a 1st option in selection 2            
            }  
            else if(option==="2nd"){
                //Click on a 2nd option in selection 2
            await this.rdo_2ndOfSecondSelectionInTrio.click({ force: true })
            } 
            else if(option==="Any"){
                //Click on a Any option in selection 2
                
                
            }    
        }
        else if(selectionNumber==3){
            if(option==="1st"){
                //Click on a 1st option in selection 3            
            }  
            else if(option==="2nd"){
                //Click on a 2nd option in selection 3           
            }             
            else if(option==="3rd"){
                //Click on a 3rd option in selection 3
                await this.rdo_3rdOfThirdSelectionInTrio.click({ force: true })
            }
             
        }  
        
      //  await this.page.waitForTimeout(1000)             
    }

    //Click on Add to Bet Slip button
    async rc_ClickOnAddToBetSlipButton() {
        await this.page.waitForTimeout(2000)
        //click on Add to bet slip button       
        await this.btn_AddToBetSlip.click()               
    }

    //Verify that trio tab is visible & enable for kiran virtual races
    async rc_VerifyThatTrioButtionIsVisibleForKironVirtualRaces() {
        await this.page.waitForTimeout(1000)
        //click on Add to bet slip button  
        await expect(this.btn_Trio, 'Trio button is visible for kiron virtual races').toBeVisible()           
    }
    
    //Store the decimal or fraction status of a odd value     
    async rc_StoreDecimalOrFractionStatus(){

        await this.page.waitForTimeout(5000)
        const oddFractionStatus="Null"
        //Store the inner text of the odd value
        const firstOddButton =await this.btn_FirstODDValue.innerText()
        if(firstOddButton.includes(".")){
            console.log("truess")
            oddFractionStatus=="decimal"
        }
        else if(firstOddButton.includes("/")){
            oddFractionStatus=="fraction"
        }              
        return oddFractionStatus     
                
    }  
}