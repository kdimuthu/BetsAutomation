
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { login } from '../testdata/testdata.json'
import { SoccerPage } from '../pages_betts/soccerpage.js'

//Verify Minimum Slip Amount Validation for Soccer Sports
test('tc_SO001_VerifyMiniumuSlipAmountValidationForSoccerSports', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
    //Click on Soccer tab
    await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
    const _SoccerPage=new SoccerPage(page)
    //Click on first game   
    await _SoccerPage.rc_ClickOnFirstGame()
    //Click on first ODD
    await _SoccerPage.rc_ClickOnOddButtonInWinnerMarket("First")
    //Enter bet amount
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'25')
    //Click Place Bet button
    await _HomePage.rc_ClickPlaceBet()
    //Verify validation
    await _HomePage.rc_VerifyMinimumSlipAmountValidation()     
})

//Verify that punter is able to place a bet from Sport View
test('tc_SO002_VerifyThatUserIsAbleToPlaceABetForSoccerSportFromSportView', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","1x2","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet for winner market from single Sport View
test('tc_SO003_VerifyThatUserIsAbleToPlaceForAWinnerMarketForSoccerSportFromSingleSportView', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on first game   
  await _SoccerPage.rc_ClickOnFirstGame()
  //Click on first ODD
  await _SoccerPage.rc_ClickOnOddButtonInWinnerMarket("First")  
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Match Winner","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet for different market (Double chance) from single Sport View
test('tc_SO004_VerifyThatUserIsAbleToPlaceABetForDifferentMarketForSoccerSportFromSingleSportView', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on first game   
  await _SoccerPage.rc_ClickOnFirstGame()
  //Expand a differnt market
  await _SoccerPage.rc_ClickOnSecondMarket()
  //Click on first ODD
  await _SoccerPage.rc_ClickOnOddButtonInSecondMarket("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForSoccer(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place Single bets using multiple options
test('tc_SO005_VerifyThatUserIsAbleToPlaceSingleBetsUsingMultipleOptionsForSoccerSports', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on first game   
  await _SoccerPage.rc_ClickOnFirstGame()
  //Click on first ODD
  await _SoccerPage.rc_ClickOnOddButtonInWinnerMarket("First") 
  //Click on second ODD
  await _SoccerPage.rc_ClickOnOddButtonInWinnerMarket("Second")   
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Single","Win","30")  
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss message  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Match Winner","30")  
  //await page.pause()  
})

//Verify that punter is able to place double bets using multiple options
test('tc_SO006_VerifyThatUserIsAbleToPlaceDoulbleBetsUsingMultipleOptionsForSoccerSports', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("First")
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("Second")     
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Double","Win","30")  
  //Click place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss message  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForWinDoubleBet(slipId,"30","1x2","00")    
  //await page.pause()  
})

//Verify that punter is able to place a bet from Sport View from tomorrow tab
test('tc_SO007_VerifyThatUserIsAbleToPlaceABetForSoccerSportFromSportViewInTomorrowTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on tomorow tab
  await _SoccerPage.rc_ClickTodayTommorowOrFuture("Tomorrow")
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","1x2","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet for winner market from single Sport View from tomorrow tab
test('tc_SO008_VerifyThatUserIsAbleToPlaceABetForAWinnerMarketForSoccerSportFromSingleSportViewInTomorrowTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on tomorow tab
  await _SoccerPage.rc_ClickTodayTommorowOrFuture("Tomorrow")
  //Click on first game   
  await _SoccerPage.rc_ClickOnFirstGame()
  //Click on first ODD
  await _SoccerPage.rc_ClickOnOddButtonInWinnerMarket("First")  
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Match Winner","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet from Sport View from future tab
test('tc_SO009_VerifyThatUserIsAbleToPlaceABetForSoccerSportFromSportViewInFutureTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on tomorow tab
  await _SoccerPage.rc_ClickTodayTommorowOrFuture("Future")
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","1x2","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet for winner market from single Sport View from future tab
test('tc_SO010_VerifyThatUserIsAbleToPlaceABetForAWinnerMarketForSoccerSportFromSingleSportViewInFutureTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on tomorow tab
  await _SoccerPage.rc_ClickTodayTommorowOrFuture("Future")
  //Click on first game   
  await _SoccerPage.rc_ClickOnFirstGame()
  //Click on first ODD
  await _SoccerPage.rc_ClickOnOddButtonInWinnerMarket("First")  
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Match Winner","30")
  //await page.pause()  
})

//There is a bug to be fixed.
//Verify that punter is able to place a bet for winner market from single Sport View from tounament tab
test('tc_SO011_VerifyThatUserIsAbleToPlaceABetForAWinnerMarketForSoccerSportFromTournamentTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on tomorow tab
  await _SoccerPage.rc_ClickTodayTommorowOrFuture("Future")
  //Click on first game   
  await _SoccerPage.rc_ClickOnFirstGame()
  //Click on first ODD
  await _SoccerPage.rc_ClickOnOddButtonInWinnerMarket("First")  
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Match Winner","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet from outrights tab
test('tc_SO012_VerifyThatUserIsAbleToPlaceABetForSoccerSportFromOutrightsTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on tomorow tab
  await _SoccerPage.rc_ClickOnMatchesTournamentsOrOutrights("Outrights")
  //Click on first game   
  await _SoccerPage.rc_ExpandAGameInOutrightGame("First")
  //Click on first ODD
  await _SoccerPage.rc_ClickOnOddButtonInFirstOutright("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

