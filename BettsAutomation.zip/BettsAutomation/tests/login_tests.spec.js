import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { login } from '../testdata/testdata.json'

//Verify that user is able to login with valid credential
test('tc_LO001_VerifyThatUserIsAbleToLoginWithValidCredential', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
    //Verify Succuss
    await _HomePage.rc_VerifyLoginSuccess()
   // await page.pause()
})

 