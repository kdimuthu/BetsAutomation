
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { WatchAndBetPage } from '../pages_betts/watchandbet.js';
import { login } from '../testdata/testdata.json'

//Verify that user is able to place bet using watch and bet when there is no access permition
test('tc_WA_001_VerifyThatUserIsUnableToPlaceBetsUsingWachAndBetWhenThereIsNoAccessPermision', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
    //Click on Soccer tab
    await _HomePage.rc_ClickAnItemFromTopMenu("Watch")
    const _WatchAndBetPage=new WatchAndBetPage(page)
    //Verify fail messge
    await _WatchAndBetPage.rc_VerifyFailMessageWhenNoAccessToWatchAndBet()
   // await page.pause()
})

