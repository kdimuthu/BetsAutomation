
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { login } from '../testdata/testdata.json'
import { RacingPage } from '../pages_betts/racingpage.js'
import { Next15Page } from '../pages_betts/next15page.js';

//Verify Minimum Slip Amount Validation for TAB Races
test('tc_TAB001_VerifyMiniumuSlipAmountValidationForTabRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on first SP/Odd/Bet   
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '25')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify validation
  await _HomePage.rc_VerifyMinimumSlipAmountValidation()
})

//Verify Minimum Stake Value Validation for Tab races
test('tc_TAB002_VerifyMiniumuStakeValueValidationForTabRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Click on first SP/Odd/Bet 
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '20')
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place", '5')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify validation
  await _HomePage.rc_VerifyMinimumStakeValueValidation()

})

//Verify that user is able to place a bet for TAB Races from Todays tab
test('tc_TAB003_VerifyThatUserIsAbleToPlaceABetForTABRacesFromTodaysTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "30", "Win", "30")
  //await page.pause()
})

//Verify that user is able to place a win bet for TAB Races 
test('tc_TAB004_VerifyThatUserIsAbleToPlaceAWinBetForTABRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "30", "Win", "30")
  //await page.pause()
})

//Verify that user is not able to place a place only bet for TAB Races 
test('tc_TAB005_VerifyThatUserIsNotAbleToPlaceAPlaceOnlyBetForTABRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet validation message
  await _HomePage.rc_VerifyValidationWhenPlaceOnlyBetIsPlaced() 
  //await page.pause()
})

//Verify that user is able to place a wind & place bet for TAB Races 
test('tc_TAB006_VerifyThatUserIsAbleToPlaceAWinAndPlaceBetForTABRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("WinAndPlace", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "60", "Win", "30")
  //Verify bet details for second selction
  await _HomePage.rc_VerifyBetDetailsWhenBettinsForMultipleSelection("Place", "30")
  //await page.pause()
})

//Verify that validation message when place stake is grater than win stake for TAB races
test('tc_TAB007_UnableToPlaceASingleBetWhenPlaceIsGreaterThanWinForTABRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter win amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Enter an ammount for place bet
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place", '40')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyValidationWhenPlaceIsGraterThanWin()
  //await page.pause()
})

//Verify that user is able to place bet using Each Way for TAB Races 
test('tc_TAB008_VerifyPlacingABetUsingEachWayForTABRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter an ammount for win bet
  await _HomePage.rc_EnterAStakeViaEachWay("30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "60", "Each Way", "60")
  //await page.pause()
})

//Verify that user is able to place a single bet for two races using multiple options for TAB Races
test('tc_TAB009_VerifyPlacingASingleBetForTwoRacesUsingMultipleOptionsForTABRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Clik on Bet for first race    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Clik on Bet for second race    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Single", "Win", "30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  //  await _HomePage.rc_VerifyBettsSuccessMessage()  
  //Store slip id and click Ok from succuss messge
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "60", "Win", "30")
  // await page.pause()

})

//Verify that user is able to place a double bet for two races using multiple options for TAB races
test('tc_TAB010_VerifyPlacingADoubleBetForTwoRacesUsingMultipleOptionsForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on last SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Clik on Bet for first race    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Click on Racing again
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("1stTAB")
  //Click on second SIS race on tomorrow tab
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Double","Win","30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForWinDoubleBet(slipId,"30","Double","00")
  // await page.pause()

})

//Verify that user is able to place bet using quinella for TAB races
test('tc_TAB011_VerifyPlacingABetUsingQuinellaForTabRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on quinella
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_ClickAMarketFromRAceCard("Quinella")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1, "1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2, "2nd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "30", "Quinella", "30")
})

//Verify that user is able to place bet using Exacta for TAB races
test('tc_TAB012_VerifyPlacingABetUsingExactaForTabRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on quinella
  const _Next15Page = new Next15Page(page)
  //Click on Exacta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Exacta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1, "1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2, "2nd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "30", "Exacta", "30")
})

//Verify that user is able to place bet using Reverse Exacta for TAB races
test('tc_TAB013_VerifyPlacingABetUsingReverseExactaForTabRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")  
  //Click on quinella
  const _Next15Page = new Next15Page(page)
  //Click on Exacta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Exacta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1, "Any")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2, "Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "60", "Reverse Exacta", "30")
})

//Verify that user is able to place bet using Trifecta for TAB races
test('tc_TAB14_VerifyPlacingABetUsingTrifectaForTabRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")   
  const _Next15Page = new Next15Page(page)
  //Click on Trifecta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Trifecta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1, "1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2, "2nd")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3, "3rd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "30", "Trifecta", "30")
})

//Verify that user is able to place bet using combination Trifecta for TAB races
test('tc_TAB015_VerifyPlacingABetUsingCombinationTrifecta', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first TAB race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")  
  const _Next15Page = new Next15Page(page)
  //Click on Trifecta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Trifecta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1, "Any")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2, "Any")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3, "Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "180", "Combination Trifecta", "30")
})

//Verify that user is able to place bet using First4 for TAB races
test('tc_TAB016_VerifyPlacingABetUsingFirst4', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB") 
  //Click on quinella
  const _Next15Page = new Next15Page(page)
  //Click on Trifecta
  await _Next15Page.rc_ClickAMarketFromRAceCard("First 4")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(1, "1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(2, "2nd")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(3, "3rd")
  //Select 3rd from selection 4
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(4, "4th")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss message  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "30", "First 4", "30")
})

//Verify that user is able to place bet using combination First4 for TAB races
test('tc_TAB017_VerifyPlacingABetUsingCombinationFirst4ForBetRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")   
  const _Next15Page = new Next15Page(page)
  //Click on First 4
  await _Next15Page.rc_ClickAMarketFromRAceCard("First 4")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(1, "Any")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(2, "Any")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(3, "Any")
  //Select 3rd from selection 4
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(4, "Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss message  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "720", "Combination First 4", "30")
})










































