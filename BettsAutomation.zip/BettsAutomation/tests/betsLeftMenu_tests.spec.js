
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { RacingPage } from '../pages_betts/racingpage.js';
import { login } from '../testdata/testdata.json';
import { LiveInPage } from '../pages_betts/liveinpage.js';
import { SoccerPage } from '../pages_betts/soccerpage.js'
import { CricketPage } from '../pages_betts/cricket.js';

//Verify that punter is able to place a bets from popular sports
test('tc_LM001_VerifyThatUserIsAbleToPlaceABetsFromPopularSports', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on first sport from popular sports
  await _HomePage.rc_ClickOnFirstSportFromPopularSports()  
  const _LiveInPage=new LiveInPage(page)  
  //Click on first odd button
  await _LiveInPage.rc_ClickOnOddButtonInrMarketFromSingleSportView("First")    
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bets for a hourse race from popular racing in left menu
test('tc_LM002_VerifyThatUserIsAbleToPlaceABetForHourseRaceFromAllRacing', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on first sport from popular sports
  await _HomePage.rc_SelectARacingTypeFromAllRacing("Horse")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip    
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()  
})

//Verify that punter is able to place a bets for a greyhound race from all racing in left menu
test('tc_LM003_VerifyThatUserIsAbleToPlaceABetForGreyhoundRaceFromAllRacing', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on first sport from popular sports
  await _HomePage.rc_SelectARacingTypeFromAllRacing("Grey")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip    
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()  
})

//Verify that punter is able to place a bets for a harness race from all racing in left menu
test('tc_LM004_VerifyThatUserIsAbleToPlaceABetForHarnessRaceFromAllRacing', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on first sport from popular sports
  await _HomePage.rc_SelectARacingTypeFromAllRacing("Harness")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("TAB")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip    
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()  
})

//Need to change. It is failing when there are no basket ball matches
//Verify that punter is able to place a bets for a basketball sport from All Sport in left menu
test('tc_LM005_VerifyThatUserIsAbleToPlaceABetForBasketballSportFromAllSportInLeftMenu', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on basketball
  await _HomePage.rc_SelectASportTypeFromAllSport("Basketball")
  const _SoccerPage=new SoccerPage(page)
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bets for a boxing sport from All Sport in left menu
test('tc_LM006_VerifyThatUserIsAbleToPlaceABetForBoxingSportFromAllSportInLeftMenu', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on basketball
  await _HomePage.rc_SelectASportTypeFromAllSport("Boxing")
  const _SoccerPage=new SoccerPage(page)
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bets for a cricket sport from All Sport in left menu
test('tc_LM007_VerifyThatUserIsAbleToPlaceABetForCricketSportFromAllSportInLeftMenu', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on basketball
  await _HomePage.rc_SelectASportTypeFromAllSport("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Need to change. It is failing when there are no basket formula
//Verify that punter is able to place a bets for a formula 1 sport from All Sport in left menu
test('tc_LM008_VerifyThatUserIsAbleToPlaceABetForFormula1SportFromAllSportInLeftMenu', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on formula
  await _HomePage.rc_SelectASportTypeFromAllSport("Formula")
  const _CricketPage=new CricketPage(page)
  //Click on first game   
  await _CricketPage.rc_ExpandAGameInOutrightGame("First")
  //Click on first ODD
  await _CricketPage.rc_ClickOnOddButtonInFirstOutright("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bets for a rugby sport from All Sport in left menu
test('tc_LM009_VerifyThatUserIsAbleToPlaceABetForRugbySportFromAllSportInLeftMenu', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on basketball
  await _HomePage.rc_SelectASportTypeFromAllSport("Rugby")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bets for a soccer sport from All Sport in left menu
test('tc_LM010_VerifyThatUserIsAbleToPlaceABetForSoccerSportFromAllSportInLeftMenu', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on basketball
  await _HomePage.rc_SelectASportTypeFromAllSport("Soccer")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bets for a tennis sport from All Sport in left menu
test('tc_LM011_VerifyThatUserIsAbleToPlaceABetForTennisSportFromAllSportInLeftMenu', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on basketball
  await _HomePage.rc_SelectASportTypeFromAllSport("Tennis")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bets from race card after clicking a race from popular racing
test('tc_LM012_VerifyThatUserIsAbleToPlaceABetsFromRaceCardByClickingARaceFromPopularRacing', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on first sport from popular sports
  await _HomePage.rc_ClickOnFirstRaceFromPopularRacing()
  //Click on first odd button
  const _RacingPage=new RacingPage(page)    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip    
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()  
})

//Verify that punter is able to place a bets by clicking an odd button from popular racing
test('tc_LM013_VerifyThatUserIsAbleToPlaceABetsByClickingAOddButtonFromPopularRacing', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on first sport from popular sports
  await _HomePage.rc_ClickOnOddButtonFromFirsSelectionFromPopularRacing()  
  //Enter bet amount for first race slip    
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()  
})









